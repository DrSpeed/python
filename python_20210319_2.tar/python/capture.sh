#!/bin/sh
# COmment
/usr/bin/python3 /home/pi/python/capture.py


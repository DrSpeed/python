Just run python3 cam.py to get streaming going.
It listens on port 8000
http://10.0.0.225:8000

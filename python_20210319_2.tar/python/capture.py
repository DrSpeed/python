import io
import picamera
from picamera import PiCamera
import logging
import socketserver
from threading import Condition
from http import server
import time
from astral import LocationInfo
import datetime
from datetime import timedelta
from datetime import timezone
from astral.sun import sun
import pytz
import os

IMG_ROOT   = '/home/pi/python/server/img'  #Needs to be absolute path for cron
IMG_TARGET = IMG_ROOT + '/cap_'
TN_TARGET  = IMG_ROOT + '/tn_cap_'

def getFileAge(path):
        # getting ctime of the file/folder
        # time will be in seconds
	ctime = os.stat(path).st_ctime
	# returning the time
	return ctime

def deleteOldFiles():
    # specify the days
    days = 1
    # converting days to seconds
    # time.time() returns current time in seconds
    seconds = time.time() - (days * 24 * 60 * 60)

    folder_path = IMG_ROOT
    for file_object in os.listdir(folder_path):
        #print('Checking ' + file_object)
        file_object_path = os.path.join(folder_path, file_object)
        if os.path.isfile(file_object_path): 
            ageInSeconds = getFileAge(file_object_path)
            if seconds >= ageInSeconds:
                print('Removing ' + file_object_path)
                os.remove(file_object_path)
            else:
                print('Not removing ' + file_object_path)

deleteOldFiles()

city = LocationInfo('San Francisco')
s = sun(city.observer, date=datetime.datetime.now())
#print(s)

sunset  = s['sunset']
sunrise = s['sunrise']

utc=pytz.UTC
now = utc.localize(datetime.datetime.now())

#test
#now = now + timedelta(hours = -1) #TEST
print('Now')
print(now)
#print('--------')
#print('Sunset')
#print(sunset)
#print('Sunrise')
#print(sunrise)

if now>sunset:
    print('after sunset')
else:
    print('before sunset')

if now>sunrise:
    print('after sunrise')
else:
    print('before sunrise')
    


# if True:  #TEST
if now >= sunrise and now <= sunset:
    print('Taking picture')
    camera = PiCamera()
    try:
        # Time/date filename
        fname = (time.strftime("%a%b%-d_%H:%M"))

        # actual file names
        full_fname = IMG_TARGET + fname + '.jpg'
        tn_fname   = TN_TARGET  + fname + '.jpg'

        #print('Saving '+ full_fname)
        camera.rotation = 180

        # 1920x1080
        # 3280x2464
        # 3280x2464
        # 1640x1232
        # 1640x922
        # 1280x720
        # 640x480
        #camera.resolution = (3280, 2464)
        camera.resolution = (1920, 1080)
        camera.annotate_background = picamera.Color('black')
        camera.annotate_text = datetime.datetime.now().strftime('%Y-%m-%d %I:%M:%S %P')
        camera.capture(full_fname)

        # Make the thumbnail, you could actually do this just from the image w/python.
        #print('resizing image ' + full_fname + ' to ' + tn_fname)
        os.system('convert ' + full_fname +  ' -resize 256x256 ' + tn_fname)
        #print('done resize')

        pass
    finally:
        camera.close()
else:
   print('Not taking picture')

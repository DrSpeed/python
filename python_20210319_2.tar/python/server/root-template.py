from flask import Flask, Response, request, abort, render_template_string, send_from_directory
from flask import Flask, render_template
import datetime
import os
from PIL import Image
#import StringIO


app = Flask(__name__)




@app.route('/<path:filename>')
def image(filename):


   #print('image handler ' + filename)
   
#   try:
      #im = Image.open(filename)
      #im.thumbnail((w, h), Image.ANTIALIAS)
      #io = StringIO.StringIO()
      #im.save(io, format='JPEG')
      #return Response(io.getvalue(), mimetype='image/jpeg')

 #  except IOError:
   #abort(404)

   return send_from_directory('.', filename)

def divideChunks(inputList, nChunks): 
      
    # looping till length l 
    for i in range(0, len(inputList), nChunks):  
        yield inputList[i:i + nChunks] 

@app.route("/")
def hello():
   now = datetime.datetime.now()
   timeString = now.strftime("%Y-%m-%d %H:%M")

   allImg = []
   folder_path = 'img'

   # sort by time

   for file_object in os.listdir(folder_path):
        file_object_path = os.path.join(folder_path, file_object)
        if os.path.isfile(file_object_path):
           if 'tn' in file_object_path:
              continue
           
           stat = os.stat(file_object_path)
           mtime = stat.st_mtime
           
           baseName = os.path.basename(file_object_path)
           oneImg = {"TN":    'tn_' + baseName,
                     "IMG":   baseName       ,
                     "CTIME": mtime,
                     "PATH":  folder_path }

           allImg.append(oneImg)

   allImg = sorted(allImg, key = lambda i: i['CTIME'])

   # Create the rows of object
   N_COLS = 5
   rowsGenerator = divideChunks(allImg, N_COLS)
   myRows = list(rowsGenerator)

   
   templateData = {
       'title'   : 'Raspberry Pi Timer Cam' ,
       'time'    : timeString ,
       'allImgs' : allImg,
       'rows' : myRows
      }


   return render_template('main.html', **templateData)

if __name__ == "__main__":
   app.run(host='0.0.0.0', port=80, debug=True)
